<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Products Base Model
 *
 * @package		Products
 * @author		Ben
 */

class Products extends CI_Controller
{

	public function __construct()
    {
        parent::__construct();
        $this->load->model('products');        
    }
	
    public function index()
    {
    	$req = array_merge($_GET, $_POST);
    	
    	$data = array();
    	$this->cart_m->get_all($data);

    	$this->template->build('productlist', $data);
    }
}