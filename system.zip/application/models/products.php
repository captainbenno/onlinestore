<?php
/**
 * Products Base Model
 *
 * @package		Products
 * @author		Ben
 */

class Productsmodel extends CI_Model {

	function __construct()
	{
		// Call the Model constructor
		
		$this->load->database();
		
	}

	function get_all()
	{
		$query = $this->db->get('product');
		return $query->result();
	}

}